const { List, db } = require('./model');


const items = [
  {
    "title": "Umbrella."
  },
  {
    "title": "Power Bank."
  },
  {
    "title": "Data Cable."
  },
  {
    "title": "Mobile charger"
  },
  {
    "title": "Watch."
  },
  {
    "title": "Earphone."
  },
  {
    "title": "Pair of cloths."
  },
  {
    "title": "Swetter/Jerkin."
  },
  {
    "title": "Underware."
  },
  {
    "title": "Pencil &amp; Rubber."
  },
  {
    "title": "Laptop."
  },
  {
    "title": "Specs"
  },
  {
    "title": "Napkin."
  },
  {
    "title": "Vicks."
  },
  {
    "title": "Luggage Cover/Spare Cover."
  },
  {
    "title": "Wallet-&gt;Check for MONEY."
  },
  {
    "title": "Laptop Charger."
  },
  {
    "title": "Match box."
  },
  {
    "title": "Mosquito Coil/ Vaporizor."
  },
  {
    "title": "Room keys."
  },
  {
    "title": "Water bottle"
  },
  {
    "title": "ATM"
  },
  {
    "title": "belt"
  },
  {
    "title": "powder"
  },
  {
    "title": "specks"
  },
  {
    "title": "medicin"
  },
  {
    "title": "Helmet"
  },
  {
    "title": "Hair combing"
  },
  {
    "title": "Shopping list"
  }
];

(async () => {
  // await db.dropDatabase();
  const resp = await Promise.all(items.map(async item => {
    try {
      const resp = await List.create(item);
      return resp;
    } catch (error) {
      console.log(error);
    }
  }));
  await db.close();
})()


